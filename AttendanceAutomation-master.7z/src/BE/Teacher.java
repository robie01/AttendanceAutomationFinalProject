/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BE;

/**
 *
 * @author robiesun
 */
public class Teacher extends Person{
    

    public Teacher(String teacherId,String teacherName, String teacherEmail, String teacherPassword) 
    {
        super(teacherId,teacherName,teacherEmail,teacherPassword);
        
    }
 
}