/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BE;

/**
 * 
 * @author robiesun
 */
public class Student extends Person{
  
    
    private String classId;
    public Student(String studentId,String studentName,String studentEmail,String stundetPassword, String studentClassId)
    {
        
        super(studentId,studentName,studentEmail, stundetPassword);
        
         this.classId = studentClassId;
}
public Student(String studentId,String studentName,String studentClassId) {
    super(studentId, studentName);
    this.classId = studentClassId;
    
    }
}