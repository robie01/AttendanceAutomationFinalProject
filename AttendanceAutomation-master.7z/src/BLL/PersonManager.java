/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BLL;

import BE.Course;
import BE.Student;
import BE.Teacher;
import DAL.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author robiesun
 */
public class PersonManager 
{
    PersonFile pf = new PersonFile();
    TeacherDB TDB = new TeacherDB();
    StudentDataManager mg = new StudentDataManager();
    CourseDataManager cdm = new CourseDataManager();
    
    
    private static PersonManager PERSONMANAGER = new PersonManager();
    
    public static PersonManager getInstance( ) 
    {
      return PERSONMANAGER;
    }
    
    public PersonManager()
    {
        
    }

//    public ArrayList<Teacher> getAllTeachers()
//    {
//        return mg.allTeachers();
//    }

    public ArrayList<Student> getAllStudents()
    {
        return mg.getStudents();
    }
    
    public ArrayList<Student> get1Students()
    {
        return mg.get1Students();
    }
    
    public ArrayList<Course> getCourse()
    {
        return cdm.getCourses();
    }
    
    public ArrayList<Teacher> getAllTeachers() 
    {
        return TDB.getTeachers();
    }
            
}
