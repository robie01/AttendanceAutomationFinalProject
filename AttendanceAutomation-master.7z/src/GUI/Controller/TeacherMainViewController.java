/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.Controller;

import BE.Lesson;
import BE.Student;
import BE.Teacher;
import BLL.PersonManager;
import DAL.CourseDataManager;
import DAL.LessonDataManager;
import GUI.Model.PersonModel;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author robiesun
 */
public class TeacherMainViewController implements Initializable {

    @FXML
    private TextField summaryTextField;
    @FXML
    private TextField attendanceTextField;
    @FXML
    private Button backButton;
    @FXML
    private TableView<Student> studentTableView;
    @FXML
    private TableColumn<Student, String> studentIdColumn;
    @FXML
    private TableColumn<Student, String> studentColumn;
    @FXML
    private TableView<Student> mostAbsentStudentsTable;
    @FXML
    private TableColumn<Student, String> mostAbsentStudentsColumn;
    @FXML
    private TableColumn<?, ?> daysMostAbsentColumn;
    @FXML
    private TextField teacherNameField;
    @FXML
    private TextField classTextField;
    @FXML
    private TextField dateTextField;
    @FXML
    private TextField courseTextField;
  
    ObservableList<Student> listOfStudents;
    PersonManager pm = PersonManager.getInstance();
    CourseDataManager cdm = new CourseDataManager();
    private Teacher teacher;
    PersonModel PM = PersonModel.getInstance();
    private Lesson selectedLesson;
    final DatePicker datePicker = new DatePicker(LocalDate.now());
    LocalDate date = datePicker.getValue();
    
    LessonDataManager ldm = new LessonDataManager();
    
    
    @FXML
    private Button saveDataButton;
    
    
    
     @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        
        studentIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        studentColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        listOfStudents = FXCollections.observableArrayList(PM.getListOfStudents1());
        studentTableView.setItems(listOfStudents);
        //setCourseName(selectedLesson);
//      summaryUpdate();
//      summaryPercentageUpdate();
       
       //dateTextField.setText(""+date);
   }    

    @FXML
    private void pressedOnTable(MouseEvent event) throws IOException
    {
        if(event.isPrimaryButtonDown() && event.getClickCount()==2)
        {
            Student selectedStudent = studentTableView.getSelectionModel().getSelectedItem();
            loadAttendanceChartTeacherView(selectedStudent);
        }
    }
    
        @FXML
    private void logOutActionBtn(ActionEvent event) {
        
        if (event.getSource() == backButton)
            {
                Stage stage = null;
                Parent root = null;
                

                //get reference to the button's stage  
                stage = (Stage) backButton.getScene().getWindow();

                //load up OTHER FXML document
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/GUI/View/LogInView.fxml"));
                try
                {
                    root = fxmlLoader.load();
                } catch (IOException ex)
                {
                    Logger.getLogger(LogInController.class.getName()).log(Level.SEVERE, null, ex);
                }

                //create a new scene with root and set the stage
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
        }w
    }
    

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }
    
    private void summaryUpdate()
    {
        String text = "";
        int inClassAmount = studentTableView.getItems().size();
        int presentAtClassAmount = 0;
        
        for(Student student : studentTableView.getItems())
        {
            if(true) //if(student.isPresent()) - after implementing attendance data
            {
                presentAtClassAmount++;
            }
        }
        
        text = presentAtClassAmount+" / "+inClassAmount;
        summaryTextField.setText(text); 
    }
    
    private void summaryPercentageUpdate()
    {
        int inClassAmount = studentTableView.getItems().size();
        int presentAtClassAmount = 0;
        int percentage = 0;
        
        for(Student student : studentTableView.getItems())
        {
            if(true) //if(student.isPresent()) - after implementing attendance data
            {
                presentAtClassAmount++;
            }
        }
     
        percentage = ((presentAtClassAmount*100)/inClassAmount);
        String text = Integer.toString(percentage);
        attendanceTextField.setText(text+"%"); 
    }
    
    void setTeacherName()
    {
        String teachersName = teacher.getName();
        teacherNameField.setText(teachersName);
    }
    
    void setCourseName(Lesson les) {
        String s = cdm.getCourseNameFromLesson(les);
        courseTextField.setText(s);
    }
   
 
    private void loadAttendanceChartTeacherView(Student student) throws IOException
    {
        Stage primStage = (Stage)studentTableView.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/GUI/View/AttendanceChartTeacherView.fxml"));
        Parent root = loader.load();
        
        AttendanceChartTeacherViewController actvc =loader.getController();
        actvc.setStudent(student);
      
        Stage stageChartView = new Stage();
        stageChartView.setScene(new Scene(root));
        
        stageChartView.initModality(Modality.WINDOW_MODAL);
        stageChartView.initOwner(primStage);
        
        stageChartView.show();
    }   


}