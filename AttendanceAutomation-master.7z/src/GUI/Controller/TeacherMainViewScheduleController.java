/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.Controller;

import BE.*;
import BLL.PersonManager;
import DAL.CourseDataManager;
import DAL.LessonDataManager;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Jesper Enemark
 */
public class TeacherMainViewScheduleController implements Initializable
{

    @FXML
    private Button logOutBtn;
    @FXML
    private Label lblName;
    @FXML
    private Label lblId;
    @FXML
    private Label lblEmail;

    @FXML
    private Label datelbl;
    @FXML
    private Label lblMonday;
    @FXML
    private Label lblTuesday;
    @FXML
    private Label lblWednesday;
    @FXML
    private Label lblThursday;
    @FXML
    private Label lblFriday;
    @FXML
    private Label lblMon1;
    @FXML
    private Label lblTues1;
    @FXML
    private Label lblWed1;
    @FXML
    private Label lblThur1;
    @FXML
    private Label lblFri1;
    @FXML
    private Label lblMon2;
    @FXML
    private Label lblTues2;
    @FXML
    private Label lblWed2;
    @FXML
    private Label lblThur2;
    @FXML
    private Label lblFri2;
    @FXML
    private Label lblDate;
    
    @FXML
    private AnchorPane anchorPane;
    @FXML
    private AnchorPane labelsAnchorPane;

    PersonManager pm = PersonManager.getInstance();
    private LessonDataManager lessonData = new LessonDataManager();
    CourseDataManager cdm = new CourseDataManager();
    
    private Teacher teacher;
    
    public Lesson selectedLesson;

    
   /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        setDate();
        putWeekDays();
        prepareSchedule();
    }

    

    public void setTeacher(Teacher teacher)
    {
        this.teacher = teacher;
    }
    public String getTeacherName() {
        
        return lblName.getText();
        
    }
    public void setTeacherName()
    {
        String teacherName = teacher.getName();
        lblName.setText(teacherName);
        
    }

    public void setTeacherId()
    {
        String teacherId = teacher.getId();
        lblId.setText(teacherId);
    }

    public void setTeacherEmail()
    {
        String teacherEmail = teacher.getEmail();
        lblEmail.setText(teacherEmail);
    }
 
    @FXML
    private void logOutBtnAction(ActionEvent event)
    {

        if (event.getSource() == logOutBtn)
        {
            Stage stage = null;
            Parent root = null;

            //get reference to the button's stage  
            stage = (Stage) logOutBtn.getScene().getWindow();

            //load up OTHER FXML document
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/GUI/View/LogInView.fxml"));
            try
            {
                root = fxmlLoader.load();
            } catch (IOException ex)
            {
                Logger.getLogger(LogInController.class.getName()).log(Level.SEVERE, null, ex);
            }

            //create a new scene with root and set the stage
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();

        }
    }

    private void putWeekDays() {
        lblMonday.setText("Monday");
        lblTuesday.setText("Tuesday");
        lblWednesday.setText("Wednesday");
        lblThursday.setText("Thursday");
        lblFriday.setText("Friday");
    }

    private void prepareSchedule() {
        int dayNumber = 0;
        String courseName;
        for (Lesson les : lessonData.getLesson()) {
            dayNumber = retrieveDayOfWeekFromLesson(les);
            courseName = cdm.getCourseNameFromLesson(les);
            
            switch (dayNumber) {
                case 3:
                    if (lblMon1.getText().isEmpty()) {
                        lblMon1.setText(courseName);
                        if(lblMon1.isPressed()){
                        selectedLesson = les;}
                    } else {
                        lblMon2.setText(courseName);
                        if(lblMon2.isPressed()){
                        selectedLesson = les;}
                    }
                case 4:
                    if (lblTues1.getText().isEmpty()) {
                        lblTues1.setText(courseName);
                        if(lblTues1.isPressed()){
                        selectedLesson = les;}
                    } else {
                        lblTues2.setText(courseName);
                        if(lblTues2.isPressed()){
                        selectedLesson = les;}
                    }
                case 5:
                    if (lblWed1.getText().isEmpty()) {
                        lblWed1.setText(courseName);
                        if(lblWed1.isPressed()){
                        selectedLesson = les;}
                    } else {
                        lblWed2.setText(courseName);
                        if(lblWed2.isPressed()){
                        selectedLesson = les;}
                    }
                case 6:
                    if (lblThur1.getText().isEmpty()) {
                        lblThur1.setText(courseName);
                        if(lblThur1.isPressed()){
                        selectedLesson = les;}
                    } else {
                        lblThur2.setText(courseName);
                        if(lblThur2.isPressed()){
                        selectedLesson = les;}
                    }
                case 7:
                    if (lblFri1.getText().isEmpty()) {
                        lblFri1.setText(courseName);
                        if(lblFri1.isPressed()){
                        selectedLesson = les;}
                    } else {
                        lblFri2.setText(courseName);
                         if(lblFri2.isPressed()){
                        selectedLesson = les;}
                    }
            }
        }
    }
    
        public int retrieveDayOfWeekFromLesson(Lesson les) {
        Lesson lessonSelected = les;
        int numberForDayOfWeek = 0;
        if (lessonSelected != null) {
            Date dateFromLesson = lessonSelected.getDate();
            Calendar c = Calendar.getInstance();
            c.setTime(dateFromLesson);
            numberForDayOfWeek = c.get(Calendar.DAY_OF_WEEK);
        }
        return numberForDayOfWeek;
    }
        
    public void setDate()
    {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        LocalDateTime now = LocalDateTime.now();
        datelbl.setText(dtf.format(now));
    }

    @FXML
    private void openAttendanceAction(MouseEvent event) throws IOException
    {
        try
        {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/GUI/View/TeacherMainView.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root1));
            stage.show();
            
                
        } catch (Exception e)
        {
            e.printStackTrace();
        }

    }
}
