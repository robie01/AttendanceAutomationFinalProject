/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.Controller;

import BE.Course;
import BE.Lesson;
import BE.Student;
import DAL.CourseDataManager;
import DAL.LessonDataManager;
import GUI.Model.PersonModel;
import java.io.IOException;
import java.net.URL;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author robiesun
 */
public class StudentMainScheduleController implements Initializable {

    @FXML
    private Button logOutBtn;
    @FXML
    private Label lblEmail;
    @FXML
    private Label lblName;
    @FXML
    private Label lblId;
    @FXML
    private Label lblDate;

    @FXML
    private Label lblMonday;
    @FXML
    private Label lblTuesday;
    @FXML
    private Label lblWednesday;
    @FXML
    private Label lblThursday;
    @FXML
    private Label lblFriday;
    @FXML
    private Label lblMon1;
    @FXML
    private Label lblMon2;
    @FXML
    private Label lblTues1;
    @FXML
    private Label lblTues2;

    public int lessonIdAtlblMon1;
    public int lessonIdAtlblMon2;
    public int lessonIdAtlblTues1;
    public int lessonIdAtlblTues2;
    public int lessonIdAtlblWed1;
    public int lessonIdAtlblWed2;
    public int lessonIdAtlblThurs1;
    public int lessonIdAtlblThurs2;
    public int lessonIdAtlblFri1;
    public int lessonIdAtlblFri2;
      public int lessonIdAtLabel;
    
    private LessonDataManager lessonData = new LessonDataManager();
    
    public int lessonIdAtThisLabel;
  
    final DatePicker datePicker = new DatePicker(LocalDate.now());
    LocalDate date = datePicker.getValue();
    CourseDataManager cdm = new CourseDataManager();

    PersonModel pm = PersonModel.getInstance();
    private Student student;
    
    @FXML
    private Label lblWed1;
    @FXML
    private Label lblThur1;
    @FXML
    private Label lblFri1;
    @FXML
    private Label lblWed2;
    @FXML
    private Label lblThur2;
    @FXML
    private Label lblFri2;

//    @FXML
//    private TableView<Lesson> tableViewLesson;
//    @FXML
//    private TableColumn<Lesson, String> Monday;
//    @FXML
//    private TableColumn<Lesson, String> Tuesday;
//    @FXML
//    private TableColumn<Lesson, String> Wednesday;
//    @FXML
//    private TableColumn<Lesson, String> Thursday;
//    @FXML
//    private TableColumn<Lesson, String> Friday;
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        System.out.println(lessonData.getLesson());
        putWeekDays();
        prepareSchedule();
//        assignLessonsToSchedule();
        // for (Lesson lesson : lessonData.getLesson()) {
        // int i = getWeekDay(lesson);
        //  System.out.println(i);    
        //   }
        //Monday.setCellValueFactory(new PropertyValueFactory("courseId"));
        //   makeLesson();
    }
    
    public String toString(int i){
        String s = "";
        return s;
    }

//    private void summaryBtnAction(ActionEvent event) {
//        
//         if (event.getSource() == summaryBtn)
//            {
//                Stage stage = null;
//                Parent root = null;
//                
//
//                //get reference to the button's stage  
//                stage = (Stage) summaryBtn.getScene().getWindow();
//
//                //load up OTHER FXML document
//                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/GUI/View/StudentAttendanceChart.fxml"));
//                try
//                {
//                    root = fxmlLoader.load();
//                } catch (IOException ex)
//                {
//                    Logger.getLogger(LogInController.class.getName()).log(Level.SEVERE, null, ex);
//                }
//
//                //create a new scene with root and set the stage
//                Scene scene = new Scene(root);
//                stage.setScene(scene);
//                stage.show();
//        }
//    }
    @FXML
    private void logOutBtnAction(ActionEvent event) {

        if (event.getSource() == logOutBtn) {
            Stage stage = null;
            Parent root = null;

            //get reference to the button's stage  
            stage = (Stage) logOutBtn.getScene().getWindow();

            //load up OTHER FXML document
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/GUI/View/LogInView.fxml"));
            try {
                root = fxmlLoader.load();
            } catch (IOException ex) {
                Logger.getLogger(LogInController.class.getName()).log(Level.SEVERE, null, ex);
            }

            //create a new scene with root and set the stage
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show(); 
        }
    }

    private void putWeekDays() {
        lblMonday.setText("Monday");
        lblTuesday.setText("Tuesday");
        lblWednesday.setText("Wednesday");
        lblThursday.setText("Thursday");
        lblFriday.setText("Friday");
    }

    private void prepareSchedule() {
        int dayNumber = 0;
        String courseName;
        for (Lesson les : lessonData.getLesson()) {
            dayNumber = retrieveDayOfWeekFromLesson(les);
            courseName = cdm.getCourseNameFromLesson(les);
            switch (dayNumber) {
                case 3:
                    if (lblMon1.getText().isEmpty()) {
                        lblMon1.setText(courseName);
                        lessonIdAtlblMon1 = les.getLessonId();
                    } else {
                        lblMon2.setText(courseName);
                        lessonIdAtlblMon2 = les.getLessonId();
                        lblMon2.setAccessibleText(toString(les.getLessonId()));
                        
                    }
                case 4:
                    if (lblTues1.getText().isEmpty()) {
                        lblTues1.setText(courseName);
                    } else {
                        lblTues2.setText(courseName);
                    }
                case 5:
                    if (lblWed1.getText().isEmpty()) {
                        lblWed1.setText(courseName);
                    } else {
                        lblWed2.setText(courseName);
                    }
                case 6:
                    if (lblThur1.getText().isEmpty()) {
                        lblThur1.setText(courseName);
                    } else {
                        lblThur2.setText(courseName);
                    }
                case 7:
                    if (lblFri1.getText().isEmpty()) {
                        lblFri1.setText(courseName);
                    } else {
                        lblFri2.setText(courseName);
                    }
            }
           
                
            
        }
    }

//                case 3:
//                    return "Monday";
//                case 4:
//                    return "Tuesday";
//                case 5:
//                    return "Wednesday";
//                case 6:
//                    return "Thursday";
//                case 7:
//                    return "Friday";
    //System.out.println(lessonData.getLesson());
    // Monday.setCellValueFactory(new PropertyValueFactory("lessonId"));
    //TableView tv = tableViewLesson.getSelectionModel().getTableView();
    //System.out.println(tv.getItems());

    /*
        private final ObservableList<Person> data =
    FXCollections.observableArrayList(
        new Person("", "Smith", ""),
    );
TableColumn col1= new TableColumn("Column1");
    firstNameCol.setCellValueFactory(
            new PropertyValueFactory<Person, String>("Column1"));

TableColumn col2= new TableColumn("Column2");
    lastNameCol.setCellValueFactory(
            new PropertyValueFactory<Person, String>("Column2"));

TableColumn col3= new TableColumn("Column3");
    lastNameCol.setCellValueFactory(
            new PropertyValueFactory<Person, String>("Column3"));

 table.setItems(data);
     table.getColumns().addAll(col1, col2, col3);
     */
//    }
//    public String getCourseNameFromLesson(Lesson lesson){
//        
//if(lesson.getCourseId()==1) && course.
//    return 
//}
//    }
    
    public int retrieveDayOfWeekFromLesson(Lesson les) {
        Lesson lessonSelected = les;
        int numberForDayOfWeek = 0;
        if (lessonSelected != null) {
            Date dateFromLesson = lessonSelected.getDate();
            Calendar c = Calendar.getInstance();
            c.setTime(dateFromLesson);
            numberForDayOfWeek = c.get(Calendar.DAY_OF_WEEK);
        }
        return numberForDayOfWeek;
    }

//        Lesson lessonSelected = les;
//        if (lessonSelected != null) {
//            Date dateFromLesson = lessonSelected.getDate();
//            Calendar c = Calendar.getInstance();
//            c.setTime(dateFromLesson);
//            int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
//
//            switch (dayOfWeek) {
//                case 3:
//                    return "Monday";
//                case 4:
//                    return "Tuesday";
//                case 5:
//                    return "Wednesday";
//                case 6:
//                    return "Thursday";
//                case 7:
//                    return "Friday";
//            }
//        }
//        return null;
//    }
//    public String retrieveDayOfWeek(Lesson les) {
//        Lesson lessonSelected = les;
//        if (lessonSelected != null) {
//            Date dateFromLesson = lessonSelected.getDate();
//            Calendar c = Calendar.getInstance();
//            c.setTime(dateFromLesson);
//            int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
//
//            switch (dayOfWeek) {
//                case 3:
//                    return "Monday";
//                case 4:
//                    return "Tuesday";
//                case 5:
//                    return "Wednesday";
//                case 6:
//                    return "Thursday";
//                case 7:
//                    return "Friday";
//            }
//        }
//        return null;
//    }
//    public void assignLessonsToSchedule() {
////
////        ObservableList<Lesson> ObservableListOfLessons;
////        List<Lesson> arrayList = new ArrayList<Lesson>();
////
////        for (Lesson les : lessonData.getLesson()) {
////        Date dateFromLesson = les.getDate();
//
//        ObservableList<Lesson> ObservableListOfLessons;
//        List<Lesson> arrayList = new ArrayList<Lesson>();
//
//        for (int i = 0; i < lessonData.getLesson().size(); i++) {
//            Lesson lessonSelected = lessonData.getLessonById(i);
//            if (lessonSelected != null) {
//                String weekDay = retrieveDayOfWeek(lessonSelected);
///*
//                login: 1
//                password: CS2016A_1
//                
// */
//
//
////                TableColumn col5 = new TableColumn("lessonId");
////                switch (weekDay) {
////                    case "Friday":
//
////                    String s = cdm.getCourseNameFromLesson(lessonSelected);
////
////                    arrayList.add(lessonSelected);
////                    Friday.setCellValueFactory(new PropertyValueFactory("courseName"));
////                   tableViewLesson.getColumns().add(col5);
////                    case "Monday":
////                    arrayList.add(lessonSelected);
////                    Monday.setCellValueFactory(new PropertyValueFactory(s));
////                }
////
////                ObservableListOfLessons = FXCollections.observableArrayList(arrayList);
////                tableViewLesson.setItems(ObservableListOfLessons);
//
//            }
//        }
//    }
//            }
//        
//            
////                switch (dayOfWeek) {
////                    case 3:
////                        Monday.setCellValueFactory(new PropertyValueFactory("lessonId"));
////                    case 4:
////                        //Tuesday.setCellValueFactory(new PropertyValueFactory("lessonId"));
////                    case 5:
////                        //Wednesday.setCellValueFactory(new PropertyValueFactory("lessonId"));
////                    case 6:
////                        //Thursday.setCellValueFactory(new PropertyValueFactory("lessonId"));
////                    case 7:
////                        //Friday.setCellValueFactory(new PropertyValueFactory("lessonId"));
////                }
//                arrayList.add(lessonSelected);
//            }
//            ObservableListOfLessons = FXCollections.observableArrayList(arrayList);
//           tableViewLesson.setItems(ObservableListOfLessons);
//        }
//    }
    public void setStudent(Student student) {
        this.student = student;
    }

    void setStudentName() {
        String studentName = student.getName();
        lblName.setText(studentName);
    }

    void setStudentId() {
        String studentId = student.getId();
        lblId.setText(studentId);
    }

    void setStudentEmail() {
        String studentEmail = student.getEmail();
        lblEmail.setText(studentEmail);
    }

//    public void fillColors()
//    {
//        lbl10.setText("SCO");
//        lbl10.setStyle("-fx-background-color:  #dc143c");
//        lbl20.setText("SDE");
//        lbl20.setStyle("-fx-background-color: #dc143c");
//        lbl11.setText("SDE");
//        lbl11.setStyle("-fx-background-color: #90ee90");
//        lbl12.setText("SCO");
//        lbl12.setStyle("-fx-background-color:#90ee90");
//        lbl22.setText("DBO");
//        lbl22.setStyle("-fx-background-color:#90ee90");
//        lbl13.setText("ITO");
//        lbl13.setStyle("-fx-background-color:#ffff00");
//        lbl14.setText("SCO");
//        lbl14.setStyle("-fx-background-color:#ffff00");
//
//    }
}
