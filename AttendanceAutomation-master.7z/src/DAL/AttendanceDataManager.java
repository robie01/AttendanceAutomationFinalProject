/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAL;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;


/**
 *
 * @author EdwinSilva
 */
public class AttendanceDataManager {


 

    ConnectionManager conManager;
    
    public AttendanceDataManager()
    {
        conManager = new ConnectionManager();
    }
    
    public void lessonAttendanceIntoDB(String studentId, int lessonId, boolean isPresent)
    {
        try(Connection con = conManager.getConnection())
        {
            String sqlCommand =
            "INSERT INTO Attendance(stundetId, lessonId, , lessonId) VALUES(?, ?, ?)";
            PreparedStatement pstat = con.prepareStatement(sqlCommand);
            pstat.setString(1, studentId);
            pstat.setInt(2, lessonId);
            pstat.setBoolean(3, isPresent);
        
            pstat.executeUpdate();
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle);
        }
    } 
}