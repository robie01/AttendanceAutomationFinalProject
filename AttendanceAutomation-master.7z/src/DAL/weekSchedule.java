package DAL;

import javafx.beans.property.SimpleStringProperty;

public class weekSchedule 
{
    private final SimpleStringProperty monday;
    private final SimpleStringProperty tuesday;
    private final SimpleStringProperty wednesday;
    private final SimpleStringProperty thursday;
    private final SimpleStringProperty friday;

    public weekSchedule(String mmonday, String ttuesday, String wwednesday, String tthursday, String ffriday) 
    {
        this.monday = new SimpleStringProperty (mmonday);
        this.tuesday = new SimpleStringProperty (ttuesday);
        this.wednesday = new SimpleStringProperty (wwednesday);
        this.thursday = new SimpleStringProperty (tthursday);
        this.friday = new SimpleStringProperty (ffriday);
    }
   
     public String getMonday() {
            return monday.get();
        }

        public void setMonday(String mmonday) {
            monday.set(mmonday);
        }

       public String getTuesday() {
            return tuesday.get();
        }

        public void setTuesday(String ttuesday) {
            monday.set(ttuesday);
        }
        public String getWednesday() {
            return wednesday.get();
        }

        public void setWednesday(String wwednesday) {
            monday.set(wwednesday);
            
        }public String getThursday() {
            return thursday.get();
        }

        public void setThursday(String tthursday) {
            monday.set(tthursday);
            
        }public String getFriday() {
            return monday.get();
        }

        public void setFriday(String ffriday) {
            monday.set(ffriday);
        }
        
}
